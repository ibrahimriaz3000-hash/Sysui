# SysUICustomHook (LSPosed)
1. Build: push to GitHub (workflow included) or open in Android Studio -> assembleDebug.
2. Install APK, enable in LSPosed, scope = System UI (com.android.systemui) only. Plugin classes load inside the same process.
3. Open app, search a class (list in classes/*.txt), set alpha/scale/offset/hide/text size/color, Save, restart SystemUI.
Only View-type classes are customizable; classes/*_with_methods.txt lists methods for writing custom hooks.
