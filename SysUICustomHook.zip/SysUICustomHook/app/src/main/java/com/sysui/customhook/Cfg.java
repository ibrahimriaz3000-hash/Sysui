package com.sysui.customhook;

/** Per-class settings, stored as "a=0.5;s=1;x=0;y=0;h=0;c=0;t=0". */
public class Cfg {
    public float alpha = -1, scale = -1, tx = 0, ty = 0, textSp = 0;
    public boolean hide = false;
    public int color = 0;

    public static Cfg parse(String s) {
        Cfg c = new Cfg();
        if (s == null) return c;
        for (String kv : s.split(";")) {
            String[] p = kv.split("=", 2);
            if (p.length < 2) continue;
            try {
                switch (p[0]) {
                    case "a": c.alpha = Float.parseFloat(p[1]); break;
                    case "s": c.scale = Float.parseFloat(p[1]); break;
                    case "x": c.tx = Float.parseFloat(p[1]); break;
                    case "y": c.ty = Float.parseFloat(p[1]); break;
                    case "t": c.textSp = Float.parseFloat(p[1]); break;
                    case "h": c.hide = p[1].equals("1"); break;
                    case "c": c.color = (int) Long.parseLong(p[1]); break;
                }
            } catch (Throwable ignored) { }
        }
        return c;
    }

    public String serialize() {
        return "a=" + alpha + ";s=" + scale + ";x=" + tx + ";y=" + ty + ";t=" + textSp
                + ";h=" + (hide ? 1 : 0) + ";c=" + color;
    }
}
