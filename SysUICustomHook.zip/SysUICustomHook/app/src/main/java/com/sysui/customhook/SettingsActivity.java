package com.sysui.customhook;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class SettingsActivity extends Activity {
    private final List<String> all = new ArrayList<>();
    private final List<String> shown = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private SharedPreferences sp;

    @SuppressWarnings("deprecation")
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        try { sp = getSharedPreferences("cfg", Context.MODE_WORLD_READABLE); }
        catch (Throwable t) { sp = getSharedPreferences("cfg", Context.MODE_PRIVATE); }
        load("classes_systemui.txt", "[SystemUI] ");
        load("classes_plugin.txt", "[Plugin] ");

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        EditText search = new EditText(this);
        search.setHint("Search class (e.g. Clock, Battery, QSTile)");
        ListView lv = new ListView(this);
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, shown);
        lv.setAdapter(adapter);
        root.addView(search, new LinearLayout.LayoutParams(-1, -2));
        root.addView(lv, new LinearLayout.LayoutParams(-1, -1));
        setContentView(root);
        filter("");
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int c, int d) { }
            public void onTextChanged(CharSequence s, int a, int c, int d) { filter(s.toString()); }
            public void afterTextChanged(Editable s) { }
        });
        lv.setOnItemClickListener((p, v, pos, id) -> edit(shown.get(pos).replaceFirst("^\\[[A-Za-z]+\\] ", "")));
    }

    private void load(String asset, String tag) {
        try (BufferedReader r = new BufferedReader(new InputStreamReader(getAssets().open(asset)))) {
            String l;
            while ((l = r.readLine()) != null) if (!l.trim().isEmpty()) all.add(tag + l.trim());
        } catch (Throwable ignored) { }
    }

    private void filter(String q) {
        shown.clear();
        q = q.toLowerCase();
        for (String s : all) if (s.toLowerCase().contains(q)) shown.add(s);
        adapter.notifyDataSetChanged();
    }

    private EditText field(LinearLayout l, String hint, String val) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setText(val);
        l.addView(e);
        return e;
    }

    private void edit(String cls) {
        Cfg c = Cfg.parse(sp.getString(cls, null));
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(40, 20, 40, 0);
        EditText a = field(l, "alpha 0..1 (-1 = off)", String.valueOf(c.alpha));
        EditText s = field(l, "scale (-1 = off)", String.valueOf(c.scale));
        EditText x = field(l, "translationX px", String.valueOf(c.tx));
        EditText y = field(l, "translationY px", String.valueOf(c.ty));
        EditText t = field(l, "text size sp (0 = off)", String.valueOf(c.textSp));
        EditText col = field(l, "text color ARGB hex e.g. FFFFFFFF (empty = off)",
                c.color == 0 ? "" : Integer.toHexString(c.color));
        CheckBox h = new CheckBox(this);
        h.setText("Hide this view");
        h.setChecked(c.hide);
        l.addView(h);
        ScrollView sv = new ScrollView(this);
        sv.addView(l);
        new AlertDialog.Builder(this).setTitle(cls.substring(cls.lastIndexOf('.') + 1)).setView(sv)
                .setPositiveButton("Save", (d, w) -> {
                    Cfg n = new Cfg();
                    try {
                        n.alpha = Float.parseFloat(a.getText().toString());
                        n.scale = Float.parseFloat(s.getText().toString());
                        n.tx = Float.parseFloat(x.getText().toString());
                        n.ty = Float.parseFloat(y.getText().toString());
                        n.textSp = Float.parseFloat(t.getText().toString());
                        String cs = col.getText().toString().trim();
                        n.color = cs.isEmpty() ? 0 : (int) Long.parseLong(cs, 16);
                    } catch (Throwable e) { Toast.makeText(this, "Invalid number", Toast.LENGTH_SHORT).show(); return; }
                    n.hide = h.isChecked();
                    sp.edit().putString(cls, n.serialize()).apply();
                    Toast.makeText(this, "Saved. Restart SystemUI to re-inflate views.", Toast.LENGTH_LONG).show();
                })
                .setNeutralButton("Reset", (d, w) -> sp.edit().remove(cls).apply())
                .setNegativeButton("Cancel", null).show();
    }
}
