package com.sysui.customhook;

import android.content.Context;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

import java.io.InputStreamReader;
import java.util.HashMap;
import java.util.Map;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.IXposedHookZygoteInit;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

/**
 * One global hook on View.onAttachedToWindow / setVisibility. Any view whose class name
 * is configured in the module settings gets alpha/scale/translation/hide/text changes.
 * Works for classes of MiuiSystemUI (com.android.systemui) and for classes loaded from
 * MIUISystemUIPlugin (same process, same View base class).
 */
public class MainHook implements IXposedHookLoadPackage, IXposedHookZygoteInit {
    static final String MOD_PKG = "com.sysui.customhook";
    private XSharedPreferences prefs;
    private volatile Map<String, Cfg> map = new HashMap<>();
    private long lastCheck = 0;

    @Override
    public void initZygote(StartupParam startupParam) {
        prefs = new XSharedPreferences(MOD_PKG, "cfg");
        prefs.makeWorldReadable();
    }

    private Cfg get(String cls) {
        long now = System.currentTimeMillis();
        if (now - lastCheck > 2000) {
            lastCheck = now;
            try {
                if (prefs.hasFileChanged()) {
                    prefs.reload();
                    Map<String, Cfg> m = new HashMap<>();
                    for (Map.Entry<String, ?> e : prefs.getAll().entrySet()) {
                        if (e.getValue() instanceof String) m.put(e.getKey(), Cfg.parse((String) e.getValue()));
                    }
                    map = m;
                }
            } catch (Throwable t) { XposedBridge.log("SysUICustomHook prefs: " + t); }
        }
        return map.get(cls);
    }

    private void apply(View v, Cfg c) {
        try {
            if (c.alpha >= 0) v.setAlpha(c.alpha);
            if (c.scale > 0) { v.setScaleX(c.scale); v.setScaleY(c.scale); }
            if (c.tx != 0) v.setTranslationX(c.tx);
            if (c.ty != 0) v.setTranslationY(c.ty);
            if (v instanceof TextView) {
                TextView tv = (TextView) v;
                if (c.textSp > 0) tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, c.textSp);
                if (c.color != 0) tv.setTextColor(c.color);
            }
            if (c.hide) v.setVisibility(View.GONE);
        } catch (Throwable t) { XposedBridge.log("SysUICustomHook apply: " + t); }
    }

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        if (!"com.android.systemui".equals(lp.packageName)) return;
        XposedBridge.log("SysUICustomHook loaded in SystemUI");

        XposedHelpers.findAndHookMethod(View.class, "onAttachedToWindow", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam p) {
                View v = (View) p.thisObject;
                Cfg c = get(v.getClass().getName());
                if (c != null) apply(v, c);
            }
        });
        XposedHelpers.findAndHookMethod(View.class, "setVisibility", int.class, new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam p) {
                Cfg c = get(p.thisObject.getClass().getName());
                if (c != null && c.hide) p.args[0] = View.GONE;
            }
        });
    }
}
